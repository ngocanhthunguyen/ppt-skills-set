---
name: "consistency-check"
description: "Use when the user asks to check the deck for inconsistencies — mismatched fonts, colors, capitalization, spacing, or off-brand slides — and wants a report or fixes."
---

# Consistency Check

Audits the whole deck for visual and textual inconsistencies.

## Scan every slide and flag
1. Fonts: different typefaces or sizes for the same element.
2. Colors: off-palette titles or accents, inconsistent text color.
3. Capitalization: title case mixed with sentence case.
4. Bullets: inconsistent styles, indent levels, or punctuation.
5. Alignment: objects off the grid, uneven margins or spacing.
6. Terminology: the same thing named differently across slides.

## Then
- Return a slide-by-slide list: slide number, issue, suggested fix.
- Ask "Want me to apply all the fixes?" and only act on confirmation. If the user already said fix them, apply directly.
- Don't change intentional design choices like a different section-divider style. Note those separately.
