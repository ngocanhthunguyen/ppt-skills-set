---
name: "tighten-copy"
description: "Use when the user asks to tighten slide copy, shorten bullets, cut filler, or make the text punchier and more scannable."
---

# Tighten Copy

Makes slide text lean and scannable without losing meaning.

## What to do
1. Cut every bullet to under about 10 words.
2. Remove filler ("in order to", "it is important to note", "basically", "very", "really").
3. Lead each bullet with a strong verb or the key noun.
4. Delete redundant bullets, merge overlapping points.
5. Cap bullets at 6 per slide. If more, split or move detail to speaker notes.
6. Make phrasing parallel across bullets on the same slide.

## Output
The tightened slides, plus a one-line note on how much was trimmed.

## Guardrails
- Preserve all facts, numbers, and the core message.
- Don't drop a point entirely unless it's a true duplicate, condense instead.
