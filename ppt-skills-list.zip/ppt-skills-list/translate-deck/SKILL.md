---
name: "translate-deck"
description: "Use when the user asks to translate slides, notes, or the whole deck into another language, or wants a bilingual or localized version of a presentation."
---

# Translate Deck

Translates deck content into a specified target language while preserving structure and formatting.

## What to do
1. Ask for the target language if not specified.
2. Translate titles, body text, and speaker notes accurately, preserving tone and meaning.
3. Keep numbers, product names, and required legal/brand terms unchanged unless told otherwise.
4. Preserve layout, bullet structure, and slide order exactly.
5. Flag any idiom with no direct equivalent, noting your best adapted version.
6. Don't translate text embedded inside images — flag it instead.

## Output
Translated deck (new copy, original untouched) + a list of flagged idioms or untranslatable image text.

## Guardrails
- Preserve factual accuracy over literal wording.
- Never guess a language if unspecified — ask.
