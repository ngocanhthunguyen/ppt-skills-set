---
name: "fix-this-slide"
description: "Use when the user says 'fix this slide', 'clean up this slide', or wants a single slide's layout, spacing, alignment, and bullets tightened without changing the message."
---

# Fix This Slide

Cleans up the current or selected slide so it looks intentional and uncluttered.

## What to do
1. Align all objects (left, top, or center as appropriate), snap to a consistent grid.
2. Even out horizontal and vertical spacing between elements.
3. Cap bullets at 6, rewrite each to a single line (under about 10 words) while keeping meaning.
4. Establish clear hierarchy: one dominant title, then supporting points.
5. Remove redundant or duplicate text, merge overlapping ideas.
6. Ensure text has breathing room and nothing runs off the slide.

## Output
The cleaned-up slide, plus a one-line note of the top 2 or 3 fixes made.

## Guardrails
- Preserve the slide's core message and all key facts and numbers.
- Don't change colors or fonts unless they're clearly broken or inconsistent.
- Don't add new content the user didn't provide.
