---
name: "doc-to-deck"
description: "Use when the user wants to turn a document, notes, an outline, or pasted content into slides — 'make this into a deck', 'draft slides from this', 'turn this doc into a presentation'."
---

# Doc to Deck

Converts source content into a clean, logically structured slide outline.

## What to do
1. Read the provided content and identify the main themes.
2. Build a deck with this structure:
   - Title slide (topic and subtitle).
   - Agenda slide (3 to 6 sections).
   - One slide per key idea, a clear title plus 3 to 5 supporting bullets, one line each.
   - Closing or next-steps slide.
3. Keep 5 to 7 content slides unless the user specifies a length.
4. Use parallel, action-oriented bullet phrasing.
5. Note where a chart, diagram, or image would strengthen a slide (as a placeholder line).

## Output
A drafted deck. In the chat, give a quick outline (slide titles) so the user can approve or reorder.

## Guardrails
- Use only the facts in the source content, flag anything you inferred.
- Don't overload slides, move detail into speaker notes if needed.
