---
name: "data-to-chart-slide"
description: "Use when the user pastes or references tabular or numeric data and asks to turn it into a chart slide, visualize data, or add a chart to the deck."
---

# Data to Chart Slide

Turns pasted or referenced tabular data into a properly formatted chart slide.

## What to do
1. Identify the data's structure (categories, series, values) from what's provided.
2. Choose a chart type: bar/column for comparisons, line for trends over time, pie only for a single simple share-of-total (max 5 slices).
3. Create one new slide with a clear, descriptive title stating what the chart shows.
4. Insert a native chart object (not an image) using the data provided.
5. Label axes and add a legend if more than one series.
6. Add a one-line takeaway callout near the chart (the "so what").

## Output
One new chart slide + the takeaway. In chat, name the chart type chosen and why.

## Guardrails
- Never invent data points; use only what was provided.
- If data is ambiguous or incomplete, ask before charting.
- One chart per slide, don't overcrowd.
