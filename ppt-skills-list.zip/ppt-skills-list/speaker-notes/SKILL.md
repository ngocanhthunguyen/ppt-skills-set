---
name: "speaker-notes"
description: "Use when the user asks to write, add, or improve speaker notes / presenter notes for slides, or wants a talk track for the deck."
---

# Speaker Notes

Writes concise presenter notes into the notes pane of each slide.

## What to do
1. For each slide, write speaker notes that:
   - Open with the one key point of the slide.
   - Add 2 or 3 supporting talking points the presenter can expand on.
   - Include a natural transition sentence into the next slide.
2. Target roughly 30 to 45 seconds of speaking per slide (about 60 to 90 words).
3. Use a conversational, spoken tone: short sentences, first person, no bullet-fragment shorthand.
4. Write them into the slide's notes pane, not onto the slide.

## Output
Notes added to each slide's notes pane. End with the estimated total talk time for the deck.

## Guardrails
- Notes should complement the slide, not just read the bullets aloud.
- Don't put speaker notes on the visible slide.
- Keep claims consistent with what's on the slide.
