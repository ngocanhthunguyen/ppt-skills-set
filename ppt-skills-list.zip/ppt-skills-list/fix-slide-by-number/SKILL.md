---
name: "fix-slide-by-number"
description: "Use when the user wants to fix or clean up ONE specific slide by number. Prefer this over fix-this-slide when Copilot cannot detect which slide is currently open or selected in the session."
---

# Fix Slide By Number

Cleans up one specific slide, confirmed by number, since this environment can't
reliably detect which slide is open or selected.

## What to do
1. If no slide number was given, ask for it first. Never guess or default to slide 1.
2. Once confirmed, clean up that slide:
   - Align objects, snap to a grid, even out spacing.
   - Cap bullets at 6, one line each, under ~10 words.
   - One dominant title, then supporting points.
   - Remove redundant/duplicate text, merge overlapping ideas.
3. Preserve every qualifier that changes meaning ("tentative," "pending," "subject
   to change," "draft") -- don't drop these while shortening.

## Output
The cleaned slide (state which slide number) + a one-line note of the top fixes.

## Guardrails
- Never act on a slide number without confirmation first.
- Preserve core message, all facts/numbers, and uncertainty qualifiers.
- Don't change colors/fonts unless clearly broken.
- Don't add content the user didn't provide.
