---
name: "sensitive-data-scan"
description: "Use when the user wants to check a deck for accidentally included sensitive or identifying data patterns, like ID numbers or policy numbers, before sharing it, especially in a clean-room or synthetic-data context."
---

# Sensitive Data Scan

Scans deck text, tables, and notes for patterns resembling structured personal or identifying data, separate from any internal-markings check.

## What to do
1. Scan every slide's text, tables, and speaker notes for number patterns resembling IDs: policy numbers, member/customer IDs, government ID formats, phone numbers, emails, account numbers.
2. Flag each match by slide number, the pattern found, and why it looks sensitive.
3. Do not assume synthetic-looking data is safe — flag it anyway and let the user confirm.
4. Also flag any full name paired with a number that could resemble a real record.
5. Never remove anything automatically — only report and ask before any change.

## Output
A slide-by-slide list of flagged patterns, each needing explicit user confirmation as safe or sensitive.

## Guardrails
- Never assume "it's just a demo" — always flag and ask.
- Does not replace legal/compliance review; first-pass technical check only.
