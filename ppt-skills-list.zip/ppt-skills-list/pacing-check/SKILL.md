---
name: "pacing-check"
description: "Use when the user wants to check if a deck's speaker notes fit within a target presentation time, and get suggestions on which slides to trim if it runs long."
---

# Pacing Check

Checks total estimated speaking time against a target meeting length and flags slides to cut or trim.

## What to do
1. Read speaker notes for every slide (or estimate ~150 words/minute if notes are missing, flagging those slides).
2. Sum estimated speaking time across all slides.
3. Ask for the target time if not specified.
4. If total exceeds target, rank slides by lowest content-priority (background/context before core asks or data) and suggest cuts, trims, or moving slides to a backup appendix.
5. If under target, note where more detail or pause time could be added.

## Output
Estimated total time vs. target, plus a ranked list of trim/cut suggestions if over time.

## Guardrails
- Never suggest cutting the ask, key data, or risk slides first — prioritize context cuts.
- State assumptions clearly if notes were missing and estimates used.
