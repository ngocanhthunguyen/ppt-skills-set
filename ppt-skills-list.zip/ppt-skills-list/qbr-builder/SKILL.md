---
name: "qbr-builder"
description: "Use when the user asks to build or structure a QBR (Quarterly Business Review) deck, or reformat content into a QBR flow: wins, pipeline/status, risks, and asks."
---

# QBR Builder

Structures content into a clean Quarterly Business Review deck.

## Build this flow
1. Title: account, quarter, presenter.
2. Executive summary: 3 headline outcomes for the quarter.
3. Wins and progress: what was delivered, with metrics where available.
4. Adoption or status: current state against targets such as usage, seats, milestones.
5. Pipeline or roadmap: next quarter's key initiatives.
6. Risks and blockers: honest list with owner and mitigation.
7. Asks and next steps: specific asks plus agreed actions with dates.

## Rules
- Pull existing or pasted content into the right sections. Mark gaps "[NEEDS DATA]".
- One message per slide. Push detail into speaker notes.
- Lead with outcomes and value, not activity.
- Never fabricate metrics, dates, or commitments. Use placeholders.
- Always pair a risk with a mitigation.
- End with the list of "[NEEDS DATA]" placeholders to fill in.
