---
name: "fix-fonts"
description: "Use when I ask Copilot to standardize, replace, fix, or clean up fonts across the current PowerPoint presentation. Change editable slide text to Segoe UI and adjust font sizes so text keeps its prior visual scale and fits its existing container."
---

# Fix Fonts

1. Set the theme font scheme to Segoe UI so new slides inherit it.
2. Replace overrides on slides, layouts, masters, and notes: Calibri, Georgia, Arial, Aptos to Segoe UI. Calibri Light to Segoe UI Light. Keep symbol fonts like Wingdings.
3. Leave East Asian and complex-script slots empty for language fallback.
4. Keep bold, italic, color, alignment, bullets, spacing, caps, and hierarchy.
5. Check every text element. Tell overflow apart from text that looks undersized or loose in its box.
6. Grow body text under 10pt where space allows. Leave footers, citations, legal, and page numbers small.
7. Recheck wrapping, clipping, overflow, and collisions. Keep text in its container and move objects only to restore fit.
8. Ignore decorative overlaps like circles or accent bars behind text.
9. Change fonts and sizes only. Never rewrite or cut content.
10. Report what changed and anything you could not update, like text inside images.
