---
name: "visual-suggestion-pass"
description: "Use when the user wants suggestions for where to add icons, diagrams, or images to text-heavy slides to improve engagement, without generating the images."
---

# Visual Suggestion Pass

Reviews text-heavy slides and suggests where a visual would help, without creating any images.

## What to do
1. Scan all slides for ones that are text-only or bullet-heavy with no supporting visual.
2. For each, suggest a specific, concrete visual idea (e.g. "a 3-step process icon row," "a simple bar chart here," "a before/after comparison graphic") tied to that slide's actual content.
3. Note where an existing icon library or brand image bank should be used instead of a generic stock image.
4. Skip slides that are intentionally sparse by design (section dividers, quote slides).

## Output
A slide-by-slide list: slide number, suggested visual type, and a one-line reason it would help.

## Guardrails
- Suggest ideas only, never generate or insert images automatically.
- Don't suggest a visual for a slide that doesn't need one just to hit a quota.
