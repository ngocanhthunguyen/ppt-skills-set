---
name: "template-migration"
description: "Use when the user wants to move a presentation from an old or deprecated template or layout onto a new approved template structure, not just recolor it."
---

# Template Migration

Migrates a deck's content from an old template's structure onto a new approved template's layouts.

## What to do
1. Identify the new template's available layouts (title, content, section, closing, etc.).
2. Map each existing slide to the closest matching new layout by content type, not visual similarity.
3. Move text, images, tables, and charts into the corresponding placeholders of the new layout.
4. Preserve all original content and meaning; don't summarize or cut during migration.
5. Flag any slide that doesn't map cleanly to an available new layout, for manual review.
6. Apply the new template's default fonts/colors as part of the migration.

## Output
Migrated deck + a list of any slides flagged for manual layout review.

## Guardrails
- Never drop content silently — flag if something didn't fit.
- Don't invent new layouts not present in the target template.
