---
name: "de-jargon"
description: "Use when the user asks to simplify slide language, remove jargon, plain-language the deck, or make text friendly for a non-technical or executive audience."
---

# De-Jargon

Rewrites slide text in plain, direct language a non-specialist can follow.

## What to do
1. Replace jargon, acronyms, and internal shorthand with plain terms (spell out an acronym the first time if it must stay).
2. Convert abstract or buzzword phrasing into concrete, everyday language.
3. Prefer active voice and short sentences.
4. Keep technical accuracy, simplify the wording, not the facts.
5. Apply to titles and bullets across the selected slides (or whole deck).

## Output
The rewritten slides, plus a short list of the jargon terms you swapped and what you changed them to.

## Guardrails
- Never change the meaning or the underlying claim.
- Keep product names, required legal terms, and metrics exact.
- If a term is essential and can't be simplified, keep it and add a 3 to 5 word plain-language gloss.
