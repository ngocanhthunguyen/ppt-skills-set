---
name: "executive-summary-slide"
description: "Use when the user asks for an executive summary slide, a one-slide TL;DR, a key-takeaways slide, or a 'so what' slide summarizing the whole deck."
---

# Executive Summary Slide

Reads the entire deck and produces a single, executive-ready summary slide.

## What to do
1. Scan all slides to extract the core narrative.
2. Create one new slide titled "Executive Summary" (insert it as slide 2, after the title).
3. Populate it with:
   - 3 key takeaways, each one line, outcome-focused, no jargon.
   - One recommended next step or the ask, clear and specific.
4. Lead with the "so what," not the process. Write for a busy executive who reads only this slide.

## Output
One new summary slide. Below it (in the chat), list the source slides each takeaway was drawn from.

## Guardrails
- Ground every takeaway in content that's actually in the deck, do not invent claims or numbers.
- Keep it to a single slide. If content overflows, prioritize the 3 highest-impact points.
