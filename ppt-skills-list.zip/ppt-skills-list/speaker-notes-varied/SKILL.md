---
name: "speaker-notes-varied"
description: "Use when the user wants speaker/presenter notes written for slides, and wants natural-sounding notes without a repetitive templated opener on every slide. Prefer this over speaker-notes if you've noticed it repeating 'The key point is...' on every slide."
---

# Speaker Notes (Varied Openers)

Writes presenter notes into the notes pane, avoiding repetitive templated phrasing.

## What to do
1. For each slide:
   - Lead with the main point in natural spoken language. Never use a templated opener
     like "The key point is" or "The main point is." Vary phrasing slide to slide.
   - Add 2-3 supporting talking points to expand on.
   - Include a natural transition into the next slide.
2. Target ~30-45 seconds per slide (about 60-90 words).
3. Conversational, spoken tone: short sentences, first person, no bullet-fragment
   shorthand, no repeated openers across slides.
4. Write into the notes pane, not onto the slide.

## Output
Notes added per slide. End with the estimated total talk time for the deck.

## Guardrails
- Notes complement the slide, don't just read the bullets aloud.
- Don't put notes on the visible slide.
- Keep claims consistent with the slide.
- Before finishing, confirm no two slides share the same opening phrase.
