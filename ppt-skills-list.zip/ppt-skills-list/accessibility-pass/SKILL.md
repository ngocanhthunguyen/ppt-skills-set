---
name: "accessibility-pass"
description: "Use when the user asks for an accessibility check or pass — alt text for images, color contrast, reading order, and legible font sizes across the deck."
---

# Accessibility Pass

Makes the deck more accessible and inclusive.

## What to do
1. Alt text: add concise, descriptive alt text to every image, chart, and non-decorative graphic. Mark purely decorative items as decorative.
2. Contrast: flag any text and background combination below WCAG AA contrast and suggest a compliant color.
3. Font size: flag body text under 18pt and titles under 28pt as hard to read from the back of a room.
4. Reading order: check that the tab and reading order of objects on each slide is logical.
5. Links and color: ensure meaning isn't conveyed by color alone, add labels where it is.

## Output
A checklist of what was fixed and what still needs the user's decision (like contrast color choices), slide by slide.

## Guardrails
- Alt text should describe the content or purpose, not just say "image."
- Don't restyle the whole deck, make targeted accessibility fixes only.
