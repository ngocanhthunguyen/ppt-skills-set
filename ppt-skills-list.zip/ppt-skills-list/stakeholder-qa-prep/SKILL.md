---
name: "stakeholder-qa-prep"
description: "Use when the user is preparing to present a deck and wants likely stakeholder questions and suggested answers, or wants to rehearse tough questions before a review."
---

# Stakeholder Q&A Prep

Generates likely questions a stakeholder audience would ask about this deck, with suggested answers.

## What to do
1. Read the whole deck to understand claims, numbers, risks, and asks.
2. Generate 8-12 likely questions covering: numbers/methodology, risks/assumptions, cost/resourcing, timeline, and any thin points in the deck.
3. Draft a concise suggested answer for each, grounded only in the deck's content.
4. Flag any question the deck cannot currently answer, as a gap to prepare separately.
5. Order questions from most to least likely to be asked.

## Output
A numbered Q&A list (question + suggested answer), plus a short "gaps to prepare" list at the end.

## Guardrails
- Never fabricate data in an answer; if unsupported, mark it a gap.
- Keep answers concise and presenter-ready.
