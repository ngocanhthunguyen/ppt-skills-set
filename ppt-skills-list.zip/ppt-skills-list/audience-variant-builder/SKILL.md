---
name: "audience-variant-builder"
description: "Use when the user wants multiple versions of the same deck tailored to different audiences, such as executive, technical, and customer-facing versions from one source deck."
---

# Audience Variant Builder

Produces tailored versions of a deck for different specified audiences, from one source deck.

## What to do
1. Ask which audiences are needed if not specified (e.g. executive, technical, customer-facing).
2. Adjust per audience: detail level, technical depth, tone, and which slides to include or cut.
   - Executive: fewer slides, outcomes-first, minimal detail.
   - Technical: full detail, methodology, assumptions included.
   - Customer-facing: no internal metrics, plain language, no roadmap dates.
3. Keep core facts and numbers identical across all variants — only framing and depth change.
4. Save each variant as a separate copy, clearly named by audience.

## Output
One deck copy per requested audience + a short note on what changed per version.

## Guardrails
- Never change a fact between variants, only presentation and depth.
- Confirm requested audiences before generating multiple copies.
