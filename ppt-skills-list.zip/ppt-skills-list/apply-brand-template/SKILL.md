---
name: "apply-brand-template"
description: "Use when the user asks to apply the brand, make slides on-brand, reformat to the template, or standardize formatting across selected slides or the whole deck. Reformats slides to a defined visual identity (fonts, colors, layout, logo)."
---

# Apply Brand Template

Reformats selected slides, or the whole deck if none are selected, to a consistent brand look.

## Brand tokens, EDIT THESE
- Title: Segoe UI, 32pt, Bold
- Body: Segoe UI, 18pt, Regular
- Primary color for titles and accents: #2563EB
- Secondary color: #505050
- Background: #FFFFFF
- Logo: bottom-right, small, every slide except the title

## What to do
1. Set every title to the title font, size, and primary color above.
2. Set body text to the body font and size. Use the secondary color for sub-text.
3. Standardize bullets. Cap at 6 per slide, one line each.
4. Align objects to a grid and even out spacing between them.
5. Keep consistent margins so content never touches a slide edge.
6. Change formatting only. Keep all content and meaning intact.
7. Leave intentional full-bleed images and custom layouts alone. Fix only their fonts and colors.
8. End with a one-line summary of what changed.
