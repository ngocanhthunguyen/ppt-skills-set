---
name: "customer-ready-pass"
description: "Use when the user wants to make a deck customer-ready or externally shareable — strip internal notes, remove confidential markings, add a disclaimer, and confirm nothing internal-only remains."
---

# Customer-Ready Pass

Prepares an internal deck for safe external sharing.

## What to do
1. Remove internal-only speaker notes, hidden slides, DRAFT or INTERNAL watermarks, and back-channel comments.
2. Flag anything confidential, such as internal pricing, NDA roadmap dates, other parties' names, or internal metrics, and ask before removing.
3. Add a disclaimer footer or closing slide. EDIT to your approved wording: "For discussion purposes only. Subject to change."
4. Check the closing slide has the right presenter contact info.
5. Confirm no TODO, placeholder text, or lorem ipsum remains.
6. When unsure whether something is confidential, ask. Never assume it is safe to keep.
7. Remove internal or sensitive items only, never substantive content.
8. Respect sensitivity labels and say so if the file looks classified.
9. Return the cleaned deck plus a list of everything removed or flagged.
